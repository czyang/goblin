#ifndef _TETSERVERMAIN_
#define _TETSERVERMAIN_

#include "TetServerMain.h"
#include "TetNetServer.h"
#include "TetTimer.h"
#include "thread.h"

#endif