#include "TetNetServer.h"

SOCKET					ListeningSocket;
SOCKET					Player1Connection, Player2Connection;
WSADATA					wsaData;
SOCKADDR_IN				ServerAddr;
SOCKADDR_IN				ClientAddr;

ZoneInfo zi[2];

void SendtoAll ( const char *buf, int size )
{
	int iResult;
	iResult = send ( Player1Connection, buf, size, 0 );
	if ( iResult == SOCKET_ERROR )
	{
		printf ( "Fatal error socket!\n" );
	}
	iResult = send ( Player2Connection, buf, size, 0 );
	if ( iResult == SOCKET_ERROR )
	{
		printf ( "Fatal error socket!\n" );
	}
	static int sa = 0;
	sa++;
}

/*
void SendZoneAll ()
{
	zi[0].PlayerID = 0;
	zi[1].PlayerID = 1;

	for ( int i = 0; i < 2; i++ )
	{
		int *TempZone;
		TempZone = ( int* ) malloc ( sizeof ( int ) * 200 );
		MergeBlock ( BlocksSet[( GameSection + i )->CurrentBlock][( GameSection + i )->BlockDir], ( GameSection + i )->Zone, 
			( GameSection + i )->block_x, ( GameSection + i )->block_y, &( ( GameSection + i )->block_y ), 
			( GameSection + i )->CurrentBlock, &TempZone, 0 );
		for ( int j = 0; j < 200; j++ )
		{
			( zi + i )->zone[j] = *( TempZone + j ); 
		}
	}
	SendtoAll ( (char *)zi, sizeof ( ZoneInfo ) );
	SendtoAll ( (char *)( zi + 1 ), sizeof ( ZoneInfo ) );
}
*/

extern int PlayerState[2];

bool InitNetServer ( void )
{
	WSAStartup ( MAKEWORD( 2 , 2 ), &wsaData );
	ListeningSocket = socket ( AF_INET, SOCK_STREAM, IPPROTO_TCP );

	ServerAddr.sin_family = AF_INET;
	ServerAddr.sin_addr.s_addr = htonl ( INADDR_ANY );
	ServerAddr.sin_port = htons( 3003 );

	bind(ListeningSocket, (SOCKADDR *)&ServerAddr, 
		sizeof(ServerAddr));

	listen(ListeningSocket, 10);
	int ClientAddrLen = sizeof ( ClientAddr );

	printf ( "Server is started.\n" );

	//Initial game speed.
	char speed = 0;

	//Waiting for Player1 connect the server.
	Player1Connection = accept(ListeningSocket, (SOCKADDR *) &ClientAddr, &ClientAddrLen);
	if ( Player1Connection == INVALID_SOCKET )
	{
		printf ( "Accept player1 is error!\n" );
		getchar ();
		return 1;
	}
	printf ( "Player 1 is Connected\n" );
	send ( Player1Connection, &speed, sizeof ( speed ), 0 );
	PlayerState[0] = STATE_WAIT;

	//Waiting for Player2 connect the server.
	Player2Connection = accept(ListeningSocket, (SOCKADDR *) &ClientAddr, &ClientAddrLen);
	if ( Player1Connection == INVALID_SOCKET )
	{
		printf ( "Accept player1 is error!\n" );
		getchar ();
		return 1;
	}
	printf ( "Player 2 is Connected\n" );
	send ( Player2Connection, &speed, sizeof ( speed ), 0 );
	PlayerState[1] = STATE_WAIT;

	PlayerState[0] = STATE_NORMAL;
	PlayerState[1] = STATE_NORMAL;

	send ( Player1Connection, (char*)( PlayerState + 0 ), sizeof ( int ), 0 );
	send ( Player2Connection, (char*)( PlayerState + 1 ), sizeof ( int ), 0 );

	printf ("Game Start!\n");

	return true;
}

/*
void GetClientMessage()
{
	KBInfo kbi;

	fd_set  fdread;
	FD_ZERO( &fdread );
	FD_SET ( Player1Connection, &fdread );
	FD_SET ( Player1Connection, &fdread );

	timeval tm = {30, 0};
	int ret = 0;

	ret = select ( 0, &fdread, NULL, NULL, &tm );
	switch (ret)
	{
	case 0:	// No data got.
		break;
	case 1:// Get data.
		if ( FD_ISSET ( Player1Connection, &fdread ) )
		{
			recv ( Player1Connection, (char *)&kbi, sizeof ( KBInfo ), 0 );
			UpdateGame ( kbi.offset_x, kbi.offset_y, kbi.rotate, 0 );
		}
		else if ( FD_ISSET( Player2Connection, &fdread ) )
		{
			recv ( Player2Connection, (char *)&kbi, sizeof ( KBInfo ), 0 );
			UpdateGame ( kbi.offset_x, kbi.offset_y, kbi.rotate, 1 );
		}
		break;
	case SOCKET_ERROR:
		printf ( "Select error!\n" );
		getchar();
		exit (1);
		break;
	}
}
*/

bool ReleaseNetServer ( void )
{
	closesocket(Player1Connection);
	closesocket(Player2Connection);
	closesocket(ListeningSocket);

	WSACleanup();

	return true;
}