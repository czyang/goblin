#ifndef _TETTIMER_
#define _TETTIMER_

class TetTimer
{
public:
	enum TimerState
	{
		TETTIMER_RUNNING,
		TETTIMER_STOPPED,
	};
	
	float m_fTime;
	TimerState m_eState;
	LARGE_INTEGER m_PerformanceCount;

public:
	TetTimer(void);
	float Start(void);
	float Stop(void);
	void  Restart(void);
	
	float GetTime_MS(void);
	float GetTime_Second(void);
	float GetTime(void) { return GetTime_Second(); }
};

#endif