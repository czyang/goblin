#include "thread.h"

/*
void RecvClientData ( void *dummy )
{
	while (1)
	{
		KBInfo kbi;
		fd_set  fdread;
		FD_ZERO( &fdread );
		FD_SET ( Player1Connection, &fdread );
		FD_SET ( Player2Connection, &fdread );

		timeval tm = {0, 0};
		int ret = 0;
		
		ret = select ( 0, &fdread, NULL, NULL, &tm );
		switch (ret)
		{
		case 0:	// No data got.
			break;
		case 1:// Get data.
			if ( FD_ISSET ( Player1Connection, &fdread ) )
			{
				recv ( Player1Connection, (char *)&kbi, sizeof ( KBInfo ), 0 );
				UpdateGame ( kbi.offset_x, kbi.offset_y, kbi.rotate, 0 );
			}
			else if ( FD_ISSET ( Player2Connection, &fdread ) )
			{
				recv ( Player2Connection, (char *)&kbi, sizeof ( KBInfo ), 0 );
				UpdateGame ( kbi.offset_x, kbi.offset_y, kbi.rotate, 1 );
			}
			if ( kbi.offset_x != 0 || kbi.offset_y != 0 || kbi.rotate != 0 )
			{
				SendZoneAll ();
			}
			break;
		case SOCKET_ERROR:
			printf ( "Select error!\n" );
			getchar();
			exit (1);
			break;
		}
	}
}
*/