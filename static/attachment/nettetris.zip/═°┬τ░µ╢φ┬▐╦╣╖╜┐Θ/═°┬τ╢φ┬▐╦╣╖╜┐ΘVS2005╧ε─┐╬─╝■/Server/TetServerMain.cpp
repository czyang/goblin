#include "TetServerMain.h"

TetTimer g_Timer;
int PlayerState[2];

extern SOCKET Player1Connection, Player2Connection;

int main ()
{
	for ( int i = 0; i < 2; i++ )
	{
		PlayerState[i] = STATE_NOCONNECTED;
	}

	InitNetServer();


	float FrameTime;
	float ShiftTime = 0;
	//_beginthread ( RecvClientData, 0, NULL );
	//Game main loop.

	ZoneInfo *zoneinfo;
	zoneinfo = ( ZoneInfo* ) malloc ( sizeof ( ZoneInfo ) * 2 );

	bool GameOverFlag = false;

	while (1)
	{
		Sleep ( 16 );
		//FrameTime = g_Timer.Stop();
		//ShiftTime += FrameTime;
		//g_Timer.Restart();
		//
		//if ( ShiftTime >= 0.5 )
		//{
		//	ShiftTime = 0;
		//}
		//
		fd_set  fdread;
		FD_ZERO ( &fdread );
		FD_SET ( Player1Connection, &fdread );
		FD_SET ( Player2Connection, &fdread );

		timeval tm = {30, 0};
		int ret = 0;
		
		if ( ( ret = select ( 0, &fdread, NULL, NULL, &tm ) ) == SOCKET_ERROR )
		{
			printf ( "Select error!\n" );
			getchar();
			exit (1);
		}
		switch (ret)
		{
		case 0:	// No data got.
			printf ( "No date got.\n" );
			break;
		default:// Got data.
			if ( FD_ISSET ( Player1Connection, &fdread ) )
			{
				recv ( Player1Connection, ( char* )( zoneinfo + 0 ), sizeof ( ZoneInfo ), 0 );	
			}
			else if ( FD_ISSET ( Player2Connection, &fdread ) )
			{
				recv ( Player2Connection, ( char* )( zoneinfo + 1 ), sizeof ( ZoneInfo ), 0 );
			}
			for ( int i = 0; i < 2; i++ )
			{
				if ( ( zoneinfo + i )->State == STATE_LOSE )
				{
					if ( i == 1 )
						( zoneinfo + 0 )->State = STATE_WIN;
					else if ( i == 0 )
						( zoneinfo + 1 )->State = STATE_WIN;
					GameOverFlag = true;
				}
		 	}
			send ( Player2Connection, ( char* )( zoneinfo + 0 ), sizeof ( ZoneInfo ), 0 );
			send ( Player1Connection, ( char* )( zoneinfo + 1 ), sizeof ( ZoneInfo ), 0 );

			if ( GameOverFlag == true )
			{
				printf ( "Game is over!" );
				system ( "pause" );
			}

			printf ( "Send zone infomation to player.\n" );
			break;
		}
	}
	ReleaseNetServer ();
	return 0;
} 