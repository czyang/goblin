#ifndef _THREAD_
#define _THREAD_

#include <process.h>
#include "TetNetClient.h"
#include "TetNetServer.h"

void RecvClientData ( void *dummy );

#endif