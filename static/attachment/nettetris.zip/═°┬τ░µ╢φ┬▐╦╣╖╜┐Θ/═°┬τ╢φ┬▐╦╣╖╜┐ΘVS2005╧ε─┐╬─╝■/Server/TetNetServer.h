#ifndef _TETNETSERVER_
#define _TETNETSERVER_

#include <winsock2.h>
#include "stdio.h"
#include "common.h"

#pragma comment( lib, "ws2_32.lib" )

void SendtoAll ( const char *buf, int size );
bool InitNetServer ( void );
bool ReleaseNetServer ( void );
void GetClientMessage();

extern SOCKET	Player1Connection, Player2Connection;
#endif