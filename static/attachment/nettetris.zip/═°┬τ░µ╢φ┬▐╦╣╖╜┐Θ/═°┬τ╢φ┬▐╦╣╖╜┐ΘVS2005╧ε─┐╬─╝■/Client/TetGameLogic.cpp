#include "TetGameLogic.h"

Cell BlocksSet[8][4] = {
	//0
	{{
		0,0,0,0,
		0,1,1,0,
		0,1,0,0,
		0,1,0,0
	},
	{
		0,0,0,0,
		1,1,1,0,
		0,0,1,0,
		0,0,0,0
	},
	{
		0,0,1,0,
		0,0,1,0,
		0,1,1,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,1,0,0,
		0,1,1,1,
		0,0,0,0
	}},
	//1
	{{
		0,0,0,0,
		0,1,1,0,
		0,0,1,0,
		0,0,1,0
	},
	{
		0,0,0,0,
		0,0,0,1,
		0,1,1,1,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,1,0,0,
		0,1,0,0,
		0,1,1,0
	},
	{
		0,0,0,0,
		0,1,1,1,
		0,1,0,0,
		0,0,0,0
	}},
	//2
	{{
		0,0,0,0,
		1,1,1,0,
		0,1,0,0,
		0,0,0,0
	},
	{
		0,1,0,0,
		1,1,0,0,
		0,1,0,0,
		0,0,0,0
	},
	{
		0,1,0,0,
		1,1,1,0,
		0,0,0,0,
		0,0,0,0
	},
	{
		0,1,0,0,
		0,1,1,0,
		0,1,0,0,
		0,0,0,0
	}},
	//3
	{{
		0,0,0,0,
		1,1,0,0,
		0,1,1,0,
		0,0,0,0
	},
	{
		0,1,0,0,
		1,1,0,0,
		1,0,0,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		1,1,0,0,
		0,1,1,0,
		0,0,0,0
	},
	{
		0,1,0,0,
		1,1,0,0,
		1,0,0,0,
		0,0,0,0
	}},
	//4
	{{
		0,0,0,0,
		0,1,1,0,
		1,1,0,0,
		0,0,0,0
	},
	{
		1,0,0,0,
		1,1,0,0,
		0,1,0,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,1,1,0,
		1,1,0,0,
		0,0,0,0
	},
	{
		1,0,0,0,
		1,1,0,0,
		0,1,0,0,
		0,0,0,0
	}},
	//5
	{{
		0,0,0,0,
		0,1,1,0,
		0,1,1,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,1,1,0,
		0,1,1,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,1,1,0,
		0,1,1,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,1,1,0,
		0,1,1,0,
		0,0,0,0
	}},
	//6
	{{
		0,0,1,0,
		0,0,1,0,
		0,0,1,0,
		0,0,1,0
	},
	{
		0,0,0,0,
		1,1,1,1,
		0,0,0,0,
		0,0,0,0
	},
	{
		0,0,1,0,
		0,0,1,0,
		0,0,1,0,
		0,0,1,0
	},
	{
		0,0,1,0,
		0,0,1,0,
		0,0,1,0,
		0,0,1,0
	}},
	//7 zero
	{{
		0,0,0,0,
		0,0,0,0,
		0,0,0,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,0,0,0,
		0,0,0,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,0,0,0,
		0,0,0,0,
		0,0,0,0
	},
	{
		0,0,0,0,
		0,0,0,0,
		0,0,0,0,
		0,0,0,0
	}},
};

GameZone *GameSection;

extern ZoneInfo *Zi;
//Return a valuable block.
int GetBlock ()
{
	static int RandSeed = 0;

	if ( RandSeed > 100 )
		RandSeed = 0;
	srand ( time (0) + RandSeed );
	RandSeed ++;
	return rand () % BLOCKSKIND;
}

void CopyCell ( Cell &des, Cell &source )
{
	for ( int i = 0; i < 16; i++ )
	{
		des.block[i] = source.block[i];
	}
}

void CopyZone ( int* des, int* source )
{
	for ( int i = 0; i < 200; i++ )
	{
		*( des + i ) = *( source + i);
	}
}

bool InspectCover ( Cell Block, int	*zone, int bx, int by )
{
	int flag = 0;

	for ( int i = 0; i < 4; i++ )
	{
		for ( int j = 0; j < 4; j++ )
		{
			if ( by + i >= 0 && by + i <= 19 && bx + j >= 0 && bx + j <= 9 )
			{
				if ( Block.block[4*i + j] == 1 && *( zone + ( 10 * ( ( 20 - 1 ) - ( by + i ) ) + bx + j ) ) != 255 )
				{
					return false;
				}
			}
			int t =  10 * ( ( 20 - 1 ) - ( by + i ) ) + bx + j ;
			//Inspect bottom.
			if ( Block.block [4*i+j] == 1 && t < 0 )
			{
				return false;
			}
			//Inspect left side.
			if ( Block.block [4*i+j] == 1 && ( bx + j ) < 0 )
			{
				return false;
			}
			//Inspect right side.
			if ( Block.block [4*i+j] == 1 && ( bx + j ) > 9 )
			{
				return false;
			}
		}
	}
	return true;
}

Cell ConversionBlock ( Cell bk, int color )
{
	Cell temp;
	for ( int i = 0; i < 16; i++ )
	{
		if ( bk.block[i] == 0 )
		{
			temp.block[i] = 255;
		}
		else
		{
			temp.block[i] = color;
		}
	}
	return temp;
}

//Merge block with background.
void MergeBlock ( Cell Block, int *zone, int bx, int by, int *ry, int color, int **Des, int clear )
{
	Cell TempBk = ConversionBlock( Block, color );

	for ( int i = 0; i < 200; i++ )
	{
		*(*Des + i) = *( zone + i );
	}
	for ( int i = 0; i < 4; i++ )
	{
		for ( int j = 0; j < 4; j++ )
		{
			if ( by + i < 0 || bx + j < 0 )
				continue;
			int a = ( 10 * ( ( 20 - 1 ) - ( by + i ) ) + bx + j );
			if ( a >= 0 && a <= 200 )
			{
				if ( TempBk.block[ 4 * i + j ] != 255 )
					*(*Des + a) = TempBk.block[ 4 * i + j];
			}
		}
	}
	if ( clear == 1 )
	{
		int CountLine = 0;
		for ( int i = 0; i < 20; i++ )
		{
			CountLine = 0;
			for ( int j = 0; j < 10; j++ )
			{
				if ( *( *Des + i * 10 + j ) != 255 )
				{
					CountLine++;
				}
			}
			if ( CountLine == 10 )
			{
				for ( int k = i; k < 19; k++ )
				{
					for ( int m = 0; m < 10; m++ )
					{
						if ( k >= 19 )
							exit(1);
						*( *Des + ( k * 10 + m ) ) = *( *Des + ( ( k + 1 ) * 10 + m ) );
					}
				}
				i--;
				(*ry) ++;
			}
		}// end i
	}// end if (clear==1)
}

bool InitGame ()
{
	GameSection = ( GameZone* ) malloc ( sizeof ( GameZone ) * PLAYERNUM );
	for ( int i = 0; i < PLAYERNUM; i++ )
	{
		for ( int j = 0; j < 200; j++ )
		{
			( GameSection + i )->Zone[j] = BLANKBLOCK;
		}
		( GameSection + i )->CurrentBlock = GetBlock ();
		( GameSection + i )->BlockDir = 0;
		( GameSection + i )->NextBlock = GetBlock ();
		( GameSection + i )->block_x = 3;
		( GameSection + i )->block_y = 0;
		( GameSection + i )->state = STATE_WAIT;
		( GameSection + i )->Speed = 0;
		( GameSection + i )->IsNeedNew = 0;
		CopyCell( ( GameSection + i )->CellBlock, BlocksSet[( GameSection + i )->CurrentBlock][0] );
	}
	return true;
}

//If offset_x is nagative number, block left shift, otherwise block right shift.
//Offset_y is 0 or 1.
bool UpdateGame ( int offset_x, int offset_y, int Rotate, int PlayerID )	
{
	if ( offset_x != 1 && offset_x != -1 && offset_x != 0 )
		return false;

	for ( int i = 0; i < PLAYERNUM; i++ )
	{
		if ( PlayerID != i )
		{
			continue;
		}
		GameZone *TempPlayer = GameSection + i;
		//New block coming.
		if ( TempPlayer->IsNeedNew == 1 )	// Generate a new block.
		{
			TempPlayer->IsNeedNew = 0;
			TempPlayer->CurrentBlock = TempPlayer->NextBlock;
			TempPlayer->NextBlock = GetBlock ();
			TempPlayer->BlockDir = 0;
			TempPlayer->block_x = 3;
			TempPlayer->block_y = -2;
			CopyCell( TempPlayer->CellBlock, BlocksSet[TempPlayer->CurrentBlock][0] );
		}
		//Determaine wether block is coverd.
		//if ( false == InspectCover ( TempPlayer->CellBlock, TempPlayer->Zone, 
		//	TempPlayer->block_x,TempPlayer->block_y ) )
		//{
		//	//Player's zone is error or game over.
		//	TempPlayer->state = STATE_LOSE;
		//	printf ("Somebody over!\n");
		//	getchar ();
		//	exit(1);
		//}

		//Block shift.
		if ( offset_x != 0 )
		{
			if( true == InspectCover ( BlocksSet[TempPlayer->CurrentBlock][TempPlayer->BlockDir], TempPlayer->Zone, 
				( TempPlayer->block_x + offset_x ), TempPlayer->block_y + offset_y ) )
			{
				TempPlayer->block_x += offset_x;
			}
		}
		else if ( offset_y != 0 )
		{
			if( true == InspectCover ( BlocksSet[TempPlayer->CurrentBlock][TempPlayer->BlockDir], TempPlayer->Zone, 
				( TempPlayer->block_x + offset_x ), TempPlayer->block_y + offset_y ) )
			{
				TempPlayer->block_y += offset_y;
			}
			else	//Block touch down.
			{
				int *Meraged = ( int* ) malloc ( sizeof ( int ) * 200 );
				MergeBlock ( BlocksSet[TempPlayer->CurrentBlock][TempPlayer->BlockDir], TempPlayer->Zone, TempPlayer->block_x, 
					TempPlayer->block_y, &(TempPlayer->block_y), TempPlayer->CurrentBlock, &Meraged, 1 );

				CopyZone ( TempPlayer->Zone, Meraged );
				TempPlayer->CurrentBlock = 7;
				TempPlayer->IsNeedNew = 1;
			}
		}
		else if ( Rotate != 0 )
		{
			if ( true == InspectCover ( BlocksSet[TempPlayer->CurrentBlock][( TempPlayer->BlockDir + Rotate ) % 4], 
				TempPlayer->Zone, TempPlayer->block_x, TempPlayer->block_y ) )
			{
				TempPlayer->BlockDir += Rotate;
				TempPlayer->BlockDir %= 4;
			}
		}
		for ( int j = 190; j < 200; j ++ )
		{
			if ( TempPlayer->Zone[j] != 255 )
			{
				TempPlayer->state = STATE_LOSE;
				( Zi + i )->State = STATE_LOSE;
			}
		}
	}
	return true;
}


bool ReleaseGame ()
{
	delete GameSection;

	return true;
}