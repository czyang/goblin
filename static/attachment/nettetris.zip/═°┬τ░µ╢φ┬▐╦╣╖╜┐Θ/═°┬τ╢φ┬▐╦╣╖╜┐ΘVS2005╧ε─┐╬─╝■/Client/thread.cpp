#include "thread.h"

/*
void ChangeNX (void)
{
	kbi.offset_x = -1;	
}
void ChangePX (void)
{
	kbi.offset_x = 1;
}
void ChangeRotate (void)
{
	kbi.rotate = 1;
}
void ChangePY (void)
{
	kbi.offset_y = 1;
}

void GetUserInputSendToServer ( void* dummy )
{
	while ( 1 )
	{
		int tid;
		tid = GetCurrentThreadId ();
		printf ( "%d ", tid );
		// Get Keyboard information.
		kbi.offset_x = 0;
		kbi.offset_y = 0;
		kbi.rotate = 0;
		
		TetRegisterKeyDown ( TETKEY_LEFT, ChangeNX );
		TetRegisterKeyDown ( TETKEY_RIGHT, ChangePX );
		TetRegisterKeyDown ( TETKEY_UP, ChangeRotate );
		TetRegisterKeyDown ( TETKEY_DOWN, ChangePY );

		TetReadKeyboard ();
		
		KBInfo *TempKbi = &kbi;

		if ( kbi.offset_x != 0 || kbi.offset_y != 0 || kbi.rotate != 0 )
		{
			TetSend ( (char*)(TempKbi), sizeof ( KBInfo ) );
		}
	}
}
*/

/*
void GetServerMessage ( void *Zi )
{
	while (1)
	{
		fd_set  fdread;
		FD_ZERO( &fdread );
		FD_SET ( ServerSocket, &fdread );
		timeval tm = {20, 0};
		int ret = 0;
		
		Sleep ( 10 );
		ret = select ( 0, &fdread, NULL, NULL, NULL );
		switch (ret)
		{
		case 0:	// No data got.
			break;
		case 1:// Get data.
			int iResult;
			iResult = recv ( ServerSocket, ( char* )Zi, sizeof(ZoneInfo), 0 );
			if ( iResult <= 0 )
			{
				exit(1);
			}
			iResult = recv ( ServerSocket, (char*)((ZoneInfo*)(Zi) + 1), sizeof(ZoneInfo), 0 );
			if ( iResult <= 0 )
			{
				exit(1);
			}
			break;
		case SOCKET_ERROR:
			exit (1);
			break;
		}
	}
}
*/

CRITICAL_SECTION gCriticalSection;
extern GameZone *GameSection;

void SendRecvServerMessage ( void* zoneinfo )
{
	ZoneInfo TempSendZI;
	TempSendZI.PlayerID = 0;
	memset ( TempSendZI.zone, BLANKBLOCK, 200 );

	ZoneInfo TempRecvZI;
	TempRecvZI.PlayerID = 1;
	memset ( TempRecvZI.zone, BLANKBLOCK, 200 );

	while ( 1 )
	{
		Sleep ( 15 );
		EnterCriticalSection ( &gCriticalSection );
		//((ZoneInfo*)zoneinfo + 0)->State = ( GameSection + 0 )->state;
		for ( int i = 0; i < 200; i++ )
		{
			TempSendZI.zone[i] = ( (ZoneInfo*)zoneinfo + 0 )->zone[i];
		}
		TempSendZI.isChanged = ( ( ZoneInfo* )zoneinfo + 0 )->isChanged;
		( (ZoneInfo*)zoneinfo + 0 )->isChanged = 0;
		LeaveCriticalSection ( &gCriticalSection );

		TempSendZI.State = ((ZoneInfo*)zoneinfo + 0)->State;

		//Send zone infomation to server.
		if ( TempSendZI.isChanged == 1 )
		{
			TetSend ( ( char* )&TempSendZI, sizeof ( ZoneInfo ) );
		}

		fd_set  fdread;
		FD_ZERO( &fdread );
		FD_SET ( ServerSocket, &fdread );
		timeval tv = {0, 0};
		int ret = 0;

		if ( ( ret = select ( 0, &fdread, NULL, NULL, &tv ) ) == SOCKET_ERROR )
		{
			exit (1);
		}
		switch (ret)
		{
		case 0:	// No data got.
			break;
		default:// Got data.
			TetRecv ( ( char* )&TempRecvZI, sizeof ( ZoneInfo ) );
			EnterCriticalSection ( &gCriticalSection );
			for ( int i = 0; i < 200; i++ )
			{
				( ( ZoneInfo* )zoneinfo + 1 )->zone[i] = TempRecvZI.zone[i];
			}
			if ( TempRecvZI.State == STATE_LOSE )
			{
				( ( ZoneInfo* )zoneinfo + 0 )->State = STATE_WIN;
			}
			else if ( TempRecvZI.State == STATE_WIN )
			{
				( ( ZoneInfo* )zoneinfo + 0 )->State = STATE_LOSE;
			}
			LeaveCriticalSection ( &gCriticalSection );

			break;
		}
	}
}