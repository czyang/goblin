#ifndef _TETCOMMON_
#define _TETCOMMON_

#include "TetDX9.h"
#include "TetDef.h"
#include "Matrix4x4.h"


enum DevEnum
{
	TET_UNKNOWN = 1,
	TET_OPENGL,
	TET_DX9,
	TET_DX10,
};

DevEnum TetGetGraphicsDeviceType ( const char *device = NULL );
bool TetInitGraphicsDevice ( const char *device );
bool TetInitGraphicsDevice ( TetDeviceSpec &spec );
bool TetReleaseGraphicsDevice ( void );
Matrix4x4 TetMatrixOrthoRH_DirectX( float w, float h, float z_near, float z_far );
Matrix4x4 TetMatrixLookAtRH_DirectX ( Vector4 &eye, Vector4 &lookat, Vector4 &up );

extern KBInfo kbi;

#endif