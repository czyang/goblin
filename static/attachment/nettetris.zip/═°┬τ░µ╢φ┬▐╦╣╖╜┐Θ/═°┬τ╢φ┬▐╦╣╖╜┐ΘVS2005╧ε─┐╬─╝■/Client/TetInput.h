#ifndef _TETINPUT_
#define _TETINPUT_

#define DIRECTINPUT_VERSION  0x0800

#define WIN32_LEAN_AND_MEAN

#include <dinput.h>
#include "TetWin32.h"

#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "dxguid.lib")

struct TetMouseInfo
{
	// The relative movement of the mouse position.
	int x,y;
	// State of the mouse wheel to scroll.
	int z;
	// The state of the mouse button.
	unsigned char button[3];
};

struct TetJoystickInfo
{
	int x, y, z;
	int rx, ry, rz;
	int pov[4];
	unsigned char button[32];
};

enum TetInputDevice
{
	GINPUT_KEYBOARD,
	GINPUT_MOUSE,
	GINPUT_JOYSTICK
};

int TetCheckInputDevice(TetInputDevice input);
int TetInputInit(void);
int TetInputClose(void);
int TetInputRestore(void);

int TetReadKeyboard(char buffer[256]);
int TetReadMouse(TetMouseInfo *mouse);
int TetReadJoystick(TetJoystickInfo *jostick);
int TetReadJoystick(TetJoystickInfo *jostick, int whichone);

void TetReadKeyboard(void);
void TetRegisterKeyDown(int key, void (*pKeyDownFunc)(void));
void TetRegisterKeyUp  (int key, void (*pKeyDownUp)(void));
void TetRegisterKeyPressed(int key, void (*pKeyDownPressed)(void));

#define TETKEY_ESCAPE          0x01
#define TETKEY_1               0x02
#define TETKEY_2               0x03
#define TETKEY_3               0x04
#define TETKEY_4               0x05
#define TETKEY_5               0x06
#define TETKEY_6               0x07
#define TETKEY_7               0x08
#define TETKEY_8               0x09
#define TETKEY_9               0x0A
#define TETKEY_0               0x0B
#define TETKEY_MINUS           0x0C    /* - on main keyboard */
#define TETKEY_EQUALS          0x0D
#define TETKEY_BACK            0x0E    /* backspace */
#define TETKEY_TAB             0x0F
#define TETKEY_Q               0x10
#define TETKEY_W               0x11
#define TETKEY_E               0x12
#define TETKEY_R               0x13
#define TETKEY_T               0x14
#define TETKEY_Y               0x15
#define TETKEY_U               0x16
#define TETKEY_I               0x17
#define TETKEY_O               0x18
#define TETKEY_P               0x19
#define TETKEY_LBRACKET        0x1A
#define TETKEY_RBRACKET        0x1B
#define TETKEY_RETURN          0x1C    /* Enter on main keyboard */
#define TETKEY_LCONTROL        0x1D
#define TETKEY_A               0x1E
#define TETKEY_S               0x1F
#define TETKEY_D               0x20
#define TETKEY_F               0x21
#define TETKEY_G               0x22
#define TETKEY_H               0x23
#define TETKEY_J               0x24
#define TETKEY_K               0x25
#define TETKEY_L               0x26
#define TETKEY_SEMICOLON       0x27
#define TETKEY_APOSTROPHE      0x28
#define TETKEY_GRAVE           0x29    /* accent grave */
#define TETKEY_LSHIFT          0x2A
#define TETKEY_BACKSLASH       0x2B
#define TETKEY_Z               0x2C
#define TETKEY_X               0x2D
#define TETKEY_C               0x2E
#define TETKEY_V               0x2F
#define TETKEY_B               0x30
#define TETKEY_N               0x31
#define TETKEY_M               0x32
#define TETKEY_COMMA           0x33
#define TETKEY_PERIOD          0x34    /* . on main keyboard */
#define TETKEY_SLASH           0x35    /* / on main keyboard */
#define TETKEY_RSHIFT          0x36
#define TETKEY_MULTIPLY        0x37    /* * on numeric keypad */
#define TETKEY_LMENU           0x38    /* left Alt */
#define TETKEY_SPACE           0x39
#define TETKEY_CAPITAL         0x3A
#define TETKEY_F1              0x3B
#define TETKEY_F2              0x3C
#define TETKEY_F3              0x3D
#define TETKEY_F4              0x3E
#define TETKEY_F5              0x3F
#define TETKEY_F6              0x40
#define TETKEY_F7              0x41
#define TETKEY_F8              0x42
#define TETKEY_F9              0x43
#define TETKEY_F10             0x44
#define TETKEY_NUMLOCK         0x45
#define TETKEY_SCROLL          0x46    /* Scroll Lock */
#define TETKEY_NUMPAD7         0x47
#define TETKEY_NUMPAD8         0x48
#define TETKEY_NUMPAD9         0x49
#define TETKEY_SUBTRACT        0x4A    /* - on numeric keypad */
#define TETKEY_NUMPAD4         0x4B
#define TETKEY_NUMPAD5         0x4C
#define TETKEY_NUMPAD6         0x4D
#define TETKEY_ADD             0x4E    /* + on numeric keypad */
#define TETKEY_NUMPAD1         0x4F
#define TETKEY_NUMPAD2         0x50
#define TETKEY_NUMPAD3         0x51
#define TETKEY_NUMPAD0         0x52
#define TETKEY_DECIMAL         0x53    /* . on numeric keypad */
#define TETKEY_OEM_102         0x56    /* <> or \| on RT 102-key keyboard (Non-U.S.) */
#define TETKEY_F11             0x57
#define TETKEY_F12             0x58
#define TETKEY_F13             0x64    /*                     (NEC PC98) */
#define TETKEY_F14             0x65    /*                     (NEC PC98) */
#define TETKEY_F15             0x66    /*                     (NEC PC98) */
#define TETKEY_KANA            0x70    /* (Japanese keyboard)            */
#define TETKEY_ABNT_C1         0x73    /* /? on Brazilian keyboard */
#define TETKEY_CONVERT         0x79    /* (Japanese keyboard)            */
#define TETKEY_NOCONVERT       0x7B    /* (Japanese keyboard)            */
#define TETKEY_YEN             0x7D    /* (Japanese keyboard)            */
#define TETKEY_ABNT_C2         0x7E    /* Numpad . on Brazilian keyboard */
#define TETKEY_NUMPADEQUALS    0x8D    /* = on numeric keypad (NEC PC98) */
#define TETKEY_PREVTRACK       0x90    /* Previous Track (TETKEY_CIRCUMFLEX on Japanese keyboard) */
#define TETKEY_AT              0x91    /*                     (NEC PC98) */
#define TETKEY_COLON           0x92    /*                     (NEC PC98) */
#define TETKEY_UNDERLINE       0x93    /*                     (NEC PC98) */
#define TETKEY_KANJI           0x94    /* (Japanese keyboard)            */
#define TETKEY_STOP            0x95    /*                     (NEC PC98) */
#define TETKEY_AX              0x96    /*                     (Japan AX) */
#define TETKEY_UNLABELED       0x97    /*                        (J3100) */
#define TETKEY_NEXTTRACK       0x99    /* Next Track */
#define TETKEY_NUMPADENTER     0x9C    /* Enter on numeric keypad */
#define TETKEY_RCONTROL        0x9D
#define TETKEY_MUTE            0xA0    /* Mute */
#define TETKEY_CALCULATOR      0xA1    /* Calculator */
#define TETKEY_PLAYPAUSE       0xA2    /* Play / Pause */
#define TETKEY_MEDIASTOP       0xA4    /* Media Stop */
#define TETKEY_VOLUMEDOWN      0xAE    /* Volume - */
#define TETKEY_VOLUMEUP        0xB0    /* Volume + */
#define TETKEY_WEBHOME         0xB2    /* Web home */
#define TETKEY_NUMPADCOMMA     0xB3    /* , on numeric keypad (NEC PC98) */
#define TETKEY_DIVIDE          0xB5    /* / on numeric keypad */
#define TETKEY_SYSRQ           0xB7
#define TETKEY_RMENU           0xB8    /* right Alt */
#define TETKEY_PAUSE           0xC5    /* Pause */
#define TETKEY_HOME            0xC7    /* Home on arrow keypad */
#define TETKEY_UP              0xC8    /* UpArrow on arrow keypad */
#define TETKEY_PRIOR           0xC9    /* PgUp on arrow keypad */
#define TETKEY_LEFT            0xCB    /* LeftArrow on arrow keypad */
#define TETKEY_RIGHT           0xCD    /* RightArrow on arrow keypad */
#define TETKEY_END             0xCF    /* End on arrow keypad */
#define TETKEY_DOWN            0xD0    /* DownArrow on arrow keypad */
#define TETKEY_NEXT            0xD1    /* PgDn on arrow keypad */
#define TETKEY_INSERT          0xD2    /* Insert on arrow keypad */
#define TETKEY_DELETE          0xD3    /* Delete on arrow keypad */
#define TETKEY_LWIN            0xDB    /* Left Windows key */
#define TETKEY_RWIN            0xDC    /* Right Windows key */
#define TETKEY_APPS            0xDD    /* AppMenu key */
#define TETKEY_POWER           0xDE    /* System Power */
#define TETKEY_SLEEP           0xDF    /* System Sleep */
#define TETKEY_WAKE            0xE3    /* System Wake */
#define TETKEY_WEBSEARCH       0xE5    /* Web Search */
#define TETKEY_WEBFAVORITES    0xE6    /* Web Favorites */
#define TETKEY_WEBREFRESH      0xE7    /* Web Refresh */
#define TETKEY_WEBSTOP         0xE8    /* Web Stop */
#define TETKEY_WEBFORWARD      0xE9    /* Web Forward */
#define TETKEY_WEBBACK         0xEA    /* Web Back */
#define TETKEY_MYCOMPUTER      0xEB    /* My Computer */
#define TETKEY_MAIL            0xEC    /* Mail */
#define TETKEY_MEDIASELECT     0xED    /* Media Select */

/*
 *  Alternate names for keys, to facilitate transition from DOS.
 */
#define TETKEY_BACKSPACE       TETKEY_BACK            /* backspace */
#define TETKEY_NUMPADSTAR      TETKEY_MULTIPLY        /* * on numeric keypad */
#define TETKEY_LALT            TETKEY_LMENU           /* left Alt */
#define TETKEY_CAPSLOCK        TETKEY_CAPITAL         /* CapsLock */
#define TETKEY_NUMPADMINUS     TETKEY_SUBTRACT        /* - on numeric keypad */
#define TETKEY_NUMPADPLUS      TETKEY_ADD             /* + on numeric keypad */
#define TETKEY_NUMPADPERIOD    TETKEY_DECIMAL         /* . on numeric keypad */
#define TETKEY_NUMPADSLASH     TETKEY_DIVIDE          /* / on numeric keypad */
#define TETKEY_RALT            TETKEY_RMENU           /* right Alt */
#define TETKEY_UPARROW         TETKEY_UP              /* UpArrow on arrow keypad */
#define TETKEY_PGUP            TETKEY_PRIOR           /* PgUp on arrow keypad */
#define TETKEY_LEFTARROW       TETKEY_LEFT            /* LeftArrow on arrow keypad */
#define TETKEY_RIGHTARROW      TETKEY_RIGHT           /* RightArrow on arrow keypad */
#define TETKEY_DOWNARROW       TETKEY_DOWN            /* DownArrow on arrow keypad */
#define TETKEY_PGDN            GUTKEY_NEXT            /* PgDn on arrow keypad */


#endif