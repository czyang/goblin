#ifndef _TETGAMELOGIC_
#define _TETGAMELOGIC_

#include "time.h"
#include "stdlib.h"
#include "common.h"
#include "stdio.h"

#define PLAYERNUM 2

struct Cell
{
	int block[16];
};

struct GameZone
{
	int Zone[200];		//Storage the zone.
	int CurrentBlock;	//Current block.
	int BlockDir;		//Current block's direction.
	int NextBlock;		//Next block.
	int block_x;		//Current block's X coordinate.
	int block_y;		//Current block's Y coordinate.
	int state;			//Player's state, if this variate will be STATE_NORMAL, STATE_WIN, STATE_LOSE.
	Cell CellBlock;		//Block's particular infomation, determained by CurrentBlock.
	int Speed;			//Game speed.
	int IsNeedNew;
};

extern Cell BlocksSet[8][4];

int GetBlock ();
void CopyCell ( Cell &des, Cell &source );
bool InspectCover ( Cell Block, int	*zone, int bx, int by );
void MergeBlock ( Cell Block, int *zone, int bx, int by, int *ry, int color, int **Des, int Clear );
bool InitGame ();
bool UpdateGame ( int offset_x, int offset_y, int Rotate, int PlayerID );
bool ReleaseGame ();

#endif