#include "TetTexture.h"
#include "TetImage.h"
#include "TetBMP.h"

LPDIRECT3DTEXTURE9 TetLoadTexture ( const char* FileName )
{
	char file_ext[16];
	_splitpath ( FileName, NULL, NULL, NULL, file_ext );

	TetImage *pLoader = NULL;

	if ( !stricmp ( file_ext, ".bmp") )
	{
		pLoader = new BMPImg;
	}
	else 
	{
		return NULL;
	}
	LPDIRECT3DDEVICE9 device = TetGetGraphicsDeviceDX9 ();
	LPDIRECT3DTEXTURE9 pTexture = NULL;
	
	if ( IMG_OK!=pLoader->Load(FileName) )
	{
		return NULL;
	}

	int bytes_per_pixel = pLoader->GetBPP()/8;

	if ( D3D_OK != device->CreateTexture ( pLoader->GetWidth (), pLoader->GetHeight (),
		0, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &pTexture, NULL ) )
		return false;
	D3DLOCKED_RECT locked_rect;
	pTexture->LockRect ( 0, &locked_rect, NULL, 0 );

	unsigned char *target = ( unsigned char *)locked_rect.pBits;
	unsigned char *source = pLoader->GetImg();

	for ( int y = 0; y < pLoader->GetHeight(); y++ )
	{
		for ( int x = 0; x < pLoader->GetWidth (); x++ )
		{
			switch ( bytes_per_pixel )
			{
			case 1:
				target[0] = source[0];
				target[1] = source[0];
				target[2] = source[0];
				target[3] = source[0];
				source++;
				break;
			case 3:
				target[0] = source[0];
				target[1] = source[1];
				target[2] = source[2];
				target[3] = 255;
				source += 3;
				break;
			case 4:
				target[0] = source[2];
				target[1] = source[1];
				target[2] = source[0];
				target[3] = source[3];
				source += 4;
				break;
			}
			target+=4;
		}
	}
	pTexture->UnlockRect (0);

	delete pLoader;
	return pTexture;
}