#include "tetrisMain.h"

ZoneInfo *Zi, *TempZi;
extern GameZone *GameSection;

void ChangeNX (void)
{
	kbi.offset_x = -1;	
}
void ChangePX (void)
{
	kbi.offset_x = 1;
}
void ChangeRotate (void)
{
	kbi.rotate = 1;
}
void ChangePY (void)
{
	kbi.offset_y = 1;
}

void GetUserInputUpdateGame ()
{
	// Get Keyboard information.
	kbi.offset_x = 0;
	kbi.offset_y = 0;
	kbi.rotate = 0;
	
	TetRegisterKeyDown ( TETKEY_LEFT, ChangeNX );
	TetRegisterKeyDown ( TETKEY_RIGHT, ChangePX );
	TetRegisterKeyDown ( TETKEY_UP, ChangeRotate );
	TetRegisterKeyDown ( TETKEY_DOWN, ChangePY );

	TetReadKeyboard ();
	
	KBInfo *TempKbi = &kbi;

	if ( kbi.offset_x != 0 || kbi.offset_y != 0 || kbi.rotate != 0 )
	{
		if ( ( Zi + 0 )->State == STATE_NORMAL )
			UpdateGame ( kbi.offset_x, kbi.offset_y, kbi.rotate, 0 );

		EnterCriticalSection ( &gCriticalSection );
		( Zi + 0 )->isChanged = 1;
		LeaveCriticalSection ( &gCriticalSection );
	}
}

//void GetServerMsg ( void *Zi )
//{
//	fd_set  fdread;
//	FD_ZERO( &fdread );
//	FD_SET ( ServerSocket, &fdread );
//	timeval tm = {0, 0};
//	int ret = 0;
//	
//	Sleep ( 10 );
//	ret = select ( 0, &fdread, NULL, NULL, &tm );
//	switch (ret)
//	{
//	case 0:	// No data got.
//		break;
//	case 1:// Get data.
//		int iResult;
//		iResult = recv ( ServerSocket, ( char* )Zi, sizeof(ZoneInfo), 0 );
//		if ( iResult <= 0 )
//		{
//			exit(1);
//		}
//		iResult = recv ( ServerSocket, (char*)( (ZoneInfo*)(Zi) + 1), sizeof(ZoneInfo), 0 );
//		if ( iResult <= 0 )
//		{
//			exit(1);
//		}
//		break;
//	case SOCKET_ERROR:
//		exit (1);
//		break;
//	}
//}

INT WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{
	char *device = "dx9";

	int window_width, window_height;
	TetGetWindowSize ( window_width, window_height );

	TetCreateWindow ( 50, 50, window_width, window_height, device );
	if ( !TetInitGraphicsDevice ( device ) )
	{
		printf ( "failed to initialize %s device\n", device );
		exit (1);
	}

	// not support the opengl 
	int renderDev = 0;			//0=DX9  1=OpenGL
	/*
	if ( !strcmp (device, "dx9") )
	{
		renderDev = 0;
	}
	else
	{
		renderDev = 1;
	}
	*/

	//Initital all thing.
	if ( true != InitNetClient () )	//Initialize the net part, and try to connect server.
	{
		return 1;
	}
	InitResourceDX9 ();
	TetInputInit ();
	InitGame ();
	
	char speed;
	TetRecv ( &speed, sizeof(speed) );
	( GameSection + 0 )->Speed = speed;


	InitializeCriticalSection ( &gCriticalSection );

	Zi = ( ZoneInfo* ) malloc ( sizeof( ZoneInfo ) * 2 );
	TempZi = ( ZoneInfo* ) malloc ( sizeof ( ZoneInfo ) * 2 );

	for ( int i = 0; i < 2; i++ )
	{
		( Zi + i )->PlayerID = i;
		( TempZi + i )->PlayerID = i;
		for ( int j = 0; j < 200; j++ )
		{
			*( ( Zi + i )->zone + j ) = 255;
			*( ( TempZi + i )->zone + j ) = 255;
		}
		( Zi + i )->isChanged = 1;
		( TempZi + i )->isChanged = 1;
		( Zi + i )->State = STATE_NORMAL;
	}
	//End initial.

	//Wait all players ready.
	fd_set  fdread;
	FD_ZERO( &fdread );
	FD_SET ( ServerSocket, &fdread );
	timeval tv = {60, 0};
	int ret = 0;

	if ( ( ret = select ( 0, &fdread, NULL, NULL, &tv ) ) == SOCKET_ERROR )
	{
		exit (1);
	}
	switch (ret)
	{
	case 0:	// No data got.
		break;
	default:// Get data.
		TetRecv ( (char*)&( GameSection + 0 )->state, sizeof ( ( GameSection + 0 )->state ) );
		break;
	}

	_beginthread ( SendRecvServerMessage, 0, Zi );

	TetTimer tm;
	float FpsCount = 0, elasped = 0;
	
	( GameSection + 0 )->state = STATE_NORMAL;
	//main loop
	while ( TetProcessMessage() )
	{
		elasped += tm.Stop ();
		if ( elasped >= 0.5 - ( ( GameSection + 0 )->Speed * 50 )/100 )
		{
			if ( ( Zi + 0 )->State == STATE_NORMAL )
				UpdateGame ( 0, 1, 0, 0 );
			elasped = 0;
			( Zi + 0 )->isChanged = 1;
		}
		tm.Restart();
		int *TempZone;
		TempZone = ( int* ) malloc ( sizeof ( int ) * 200 );
		MergeBlock ( BlocksSet[( GameSection + 0 )->CurrentBlock][( GameSection + 0 )->BlockDir], ( GameSection + 0 )->Zone, 
			( GameSection + 0 )->block_x, ( GameSection + 0 )->block_y, &( ( GameSection + 0 )->block_y ), 
			( GameSection + 0 )->CurrentBlock, &TempZone, 0 );

		EnterCriticalSection ( &gCriticalSection );
		for ( int j = 0; j < 200; j++ )
		{
			( Zi + 0 )->zone[j] = *( TempZone + j ); 
			( TempZi + 0 )->zone[j] = *( TempZone + j);
			( TempZi + 1 )->zone[j] = ( Zi + 1 )->zone[j];
		}
		( TempZi + 0 )->State = ( Zi + 0 )->State;
		LeaveCriticalSection ( &gCriticalSection );

		GetUserInputUpdateGame ();
		RenderFrameDX9 ( TempZi );
		Sleep ( 15 );
	}
	TetInputClose();
	ReleaseNetClient ();
	TetReleaseGraphicsDevice ();
	return 0;
}