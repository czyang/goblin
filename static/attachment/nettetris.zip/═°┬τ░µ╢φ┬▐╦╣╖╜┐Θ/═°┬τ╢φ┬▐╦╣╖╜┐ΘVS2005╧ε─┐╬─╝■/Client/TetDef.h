#ifndef _TETDEF_
#define _TETDEF_

typedef unsigned char byte;

#define SAFE_RELEASE(x) if (x) { x->Release(); x=NULL; }

struct Vertex_VT
{
	float m_Position[3]; // ����λ��
	float m_Texcoord[2]; // ��ͼ����
};

struct TetCallBack
{
	void (*OnSize)(int x, int y);
	void (*OnPaint)(void);
	void (*OnIdle)(void);
	void (*OnClose)(void);

	TetCallBack(void);
};

struct TetDeviceSpec
{
	int m_iX, m_iY;
	int m_iWidth, m_iHeight;
	int m_iMultiSamples;
	bool m_bFullScreen; 
	char *m_szDevice;

	TetDeviceSpec(void)
	{
		m_iX = m_iY = 256;
		m_iWidth = m_iHeight = 512;
		m_iMultiSamples = 0;
		m_bFullScreen = false;
		m_szDevice = NULL;
	}
};

#endif