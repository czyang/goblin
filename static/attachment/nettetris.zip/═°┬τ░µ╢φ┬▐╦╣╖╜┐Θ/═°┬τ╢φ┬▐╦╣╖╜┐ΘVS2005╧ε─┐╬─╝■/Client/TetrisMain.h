#ifndef _TETRISMAIN_
#define _TETRISMAIN_


#include "TetCommon.h"
#include "TetWin32.h"
#include "TetDX9.h"
#include "stdio.h"
#include "TetInput.h"
#include "common.h"
#include "TetNetClient.h"
#include "thread.h"
#include "TetTimer.h"
#include "TetGameLogic.h"

void RenderFrameDX9 ( void );
void GetUserInputUpdateGame ();

extern CRITICAL_SECTION gCriticalSection;

#endif