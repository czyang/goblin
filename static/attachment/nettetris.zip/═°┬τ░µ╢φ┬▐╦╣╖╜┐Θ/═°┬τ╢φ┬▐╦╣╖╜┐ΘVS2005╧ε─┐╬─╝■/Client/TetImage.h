#ifndef _TETIMAGE_
#define _TETIMAGE_

#include "TetDX9.h"

class TetImage
{
public:
	TetImage ( void ) {}
	virtual ~TetImage (void) {}
	virtual int Load ( const char* szFileName ) = 0;
	virtual int GetBPP ( void ) = 0;
	virtual int GetWidth ( void ) = 0;
	virtual int GetHeight ( void ) = 0;
	virtual unsigned char* GetImg (void) = 0;
	virtual bool DownSampling ( void ) = 0;
};




#endif