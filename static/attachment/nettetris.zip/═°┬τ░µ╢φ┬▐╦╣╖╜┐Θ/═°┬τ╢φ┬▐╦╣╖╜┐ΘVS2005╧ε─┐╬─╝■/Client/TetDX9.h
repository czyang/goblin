#ifndef _TETDX9_
#define _TETDX9_

#define WIN32_LEAN_AND_MEAN

#include "TetNetClient.h"
#include "d3d9.h"
#include "d3dx9.h"
#include "TetCommon.h"
#include "Vector4.h"
#include "Matrix4x4.h"
#include "TetWin32.h"
#include "TetDef.h"
#include "TetGameZone.h"
#include "common.h"
#include <list>
#include <iostream>

#pragma comment( lib, "d3d9.lib" )
#pragma comment( lib, "d3dx9.lib" )

LPDIRECT3DDEVICE9 TetGetGraphicsDeviceDX9 ( void );
bool TetInitGraphicsDeviceDX9 ( TetDeviceSpec *pSpec = NULL );
void RenderFrameDX9( ZoneInfo *Zi );
bool TetReleaseGraphicsDeviceDX9 ( void );
bool InitResourceDX9 (void);

extern LPDIRECT3DTEXTURE9 texture_background;
extern LPDIRECT3DTEXTURE9 texture_blocks;

extern Vector4 g_eye; 
extern Vector4 g_lookat; 
extern Vector4 g_up; 

extern Matrix4x4 g_view_matrix;
extern Matrix4x4 g_world_matrix;

#endif