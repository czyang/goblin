#ifndef _TETTEXTURE_
#define _TETTEXTURE_

#include "TetDX9.h"

LPDIRECT3DTEXTURE9 TetLoadTexture ( const char* FileName );

#endif