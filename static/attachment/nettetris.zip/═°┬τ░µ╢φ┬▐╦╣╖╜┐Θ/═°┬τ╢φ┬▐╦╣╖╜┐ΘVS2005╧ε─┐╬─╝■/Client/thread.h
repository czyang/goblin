#ifndef _THREAD_
#define _THREAD_

#include "process.h"
#include "TetNetClient.h"
#include "Common.h"
#include "TetInput.h"
#include "TetCommon.h"
#include "TetGameLogic.h"

void SendRecvServerMessage ( void *zoneinfo );
void GetUserInputSendToServer ( void* dummy );

#endif