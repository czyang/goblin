#ifndef _COMMON_
#define _COMMON_

#define BLANKBLOCK			255
#define BLOCKSKIND			7

#define STATE_NORMAL		0
#define STATE_WIN			1
#define STATE_LOSE			2
#define STATE_WAIT			3
#define STATE_NOCONNECTED	-1

struct KBInfo
{
	int offset_y;
	int offset_x;
	int rotate;
};

struct ZoneInfo
{
	int PlayerID;
	int zone[200];
	int isChanged;
	int State;
};

#endif