#ifndef _TETNETCLIENT_
#define _TETNETCLIENT_

#include <winsock2.h>
#include "string.h"
#include "common.h"
#include "stdio.h"

#pragma comment ( lib, "ws2_32.lib" )

#define NETPORT 3003
#define IPADDR "127.0.0.1"

bool InitNetClient ( void );
void ReleaseNetClient ( void );
void TetSend ( const char *buf, int len );
void TetRecv ( char *buf, int len );
//void TetGetServerMessage ( ZoneInfo *Zi);

extern SOCKET			ServerSocket;		//the Socket that connected to the Server.

#endif
