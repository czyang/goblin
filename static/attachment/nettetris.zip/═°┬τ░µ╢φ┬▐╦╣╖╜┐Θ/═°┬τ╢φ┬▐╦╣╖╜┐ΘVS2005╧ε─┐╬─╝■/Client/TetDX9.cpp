#include "TetDX9.h"
#include "TetTexture.h"
#include <iostream>
#include <map>
#include "TetTimer.h"
#include "TetGameLogic.h"

static LPDIRECT3D9 g_pD3D = NULL;
static LPDIRECT3DDEVICE9 g_pD3DDevice = NULL;
static D3DPRESENT_PARAMETERS g_pD3DPresent;

Vector4 g_eye(400.0f, 300.0f, 10.0f); 
Vector4 g_lookat(400.0f, 300.0f, 0.0f); 
Vector4 g_up(0.0f, 1.0f, 0.0f); 

Matrix4x4 g_view_matrix;
Matrix4x4 g_world_matrix;

std::map<const char*, LPDIRECT3DTEXTURE9> g_TextureList;

bool ShowStart = true;


LPDIRECT3DDEVICE9 TetGetGraphicsDeviceDX9 ( void )
{
	// `ֱ�ӷ����Ѿ���ʼ���õ�Direct3D 9�豸`
	return g_pD3DDevice;
}

bool TetInitGraphicsDeviceDX9 ( TetDeviceSpec *pSpec )
{
	int multisamples = 0;
	if ( pSpec )
		multisamples = pSpec->m_iMultiSamples;
	HWND hWnd = TetGetWindowHandleWin32();
	if ( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
		return false;
	ZeroMemory ( &g_pD3DPresent, sizeof ( g_pD3DPresent ) );
	g_pD3DPresent.Windowed = TRUE;
	g_pD3DPresent.SwapEffect = D3DSWAPEFFECT_DISCARD;
	g_pD3DPresent.BackBufferFormat = D3DFMT_UNKNOWN;
	g_pD3DPresent.BackBufferCount = 1;
	g_pD3DPresent.EnableAutoDepthStencil = TRUE;
	g_pD3DPresent.AutoDepthStencilFormat = D3DFMT_D24S8;
	g_pD3DPresent.MultiSampleType = ( D3DMULTISAMPLE_TYPE) multisamples;

	bool device_initialized = false;
	const int device_types = 4;

	struct sDeviceType
	{
		D3DDEVTYPE type;
		DWORD behavior;
	};

	sDeviceType device_type[device_types] = 
	{
		{D3DDEVTYPE_HAL, D3DCREATE_HARDWARE_VERTEXPROCESSING},
		{D3DDEVTYPE_HAL, D3DCREATE_MIXED_VERTEXPROCESSING},
		{D3DDEVTYPE_HAL, D3DCREATE_SOFTWARE_VERTEXPROCESSING},
		{D3DDEVTYPE_REF, D3DCREATE_SOFTWARE_VERTEXPROCESSING}
	};

	for ( int type = 0; type < device_types; type++ )
	{
		if ( g_pD3D->CreateDevice ( D3DADAPTER_DEFAULT, device_type[type].type, hWnd, device_type[type].behavior,
			&g_pD3DPresent, &g_pD3DDevice ) == D3D_OK )
		{
			device_initialized = true;
			break;
		}
	}
	return device_initialized;
}

bool TetReleaseGraphicsDeviceDX9(void)
{
	if ( g_pD3DDevice )
	{
		g_pD3DDevice->Release();
		g_pD3DDevice = NULL;
	}

	if ( g_pD3D )
	{
		g_pD3D->Release();
		g_pD3D = NULL;
	}
	return true;
}

Vector4 CorrenctOrtho( -400.0f, -300.0f, 1.0f );

bool InitResourceDX9 (void)
{
	LPDIRECT3DDEVICE9 device = TetGetGraphicsDeviceDX9();
	Matrix4x4 projection_matrix = TetMatrixOrthoRH_DirectX( 800.0f, 600.0f, 1.0f, 100.0f );
	device->SetTransform ( D3DTS_PROJECTION, ( D3DMATRIX * ) &projection_matrix );
	device->SetRenderState ( D3DRS_LIGHTING, false );		//Close light.
	device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	g_view_matrix = TetMatrixLookAtRH_DirectX ( g_eye, g_lookat, g_up );
	g_world_matrix.Identity();

	//g_world_matrix.Translate ( CorrenctOrtho );

	//Load the textures.
#ifdef _DEBUG
	//D3DXCreateTextureFromFileEx ( device, "../../image/background.bmp", 
	//	D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
	//	D3DPOOL_MANAGED, D3DX_DEFAULT, 
	//	D3DX_DEFAULT, 0, NULL, NULL,
	//	&texture_background );
	//D3DXCreateTextureFromFileEx ( device, "../../image/blocks.bmp", 
	//	D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
	//	D3DPOOL_MANAGED, D3DX_DEFAULT, 
	//	D3DX_DEFAULT, 0, NULL, NULL,
	//	&texture_blocks);
	//D3DXCreateTextureFromFileEx ( device, "../../image/state.bmp", 
	//	D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
	//	D3DPOOL_MANAGED, D3DX_DEFAULT, 
	//	D3DX_DEFAULT, 0, NULL, NULL,
	//	&texture_blocks);
	g_TextureList.insert ( std::pair<const char*, LPDIRECT3DTEXTURE9>( "background", TetLoadTexture ("../../image/background.bmp")) );
	g_TextureList.insert ( std::pair<const char*, LPDIRECT3DTEXTURE9>( "blocks", TetLoadTexture ("../../image/blocks.bmp")) );
	g_TextureList.insert ( std::pair<const char*, LPDIRECT3DTEXTURE9>( "state", TetLoadTexture ("../../image/state.bmp")) );

#else
	//D3DXCreateTextureFromFileEx ( device, "image/background.bmp", 
	//	D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
	//	D3DPOOL_MANAGED, D3DX_DEFAULT, 
	//	D3DX_DEFAULT, 0, NULL, NULL,
	//	&texture_background );
	//D3DXCreateTextureFromFileEx ( device, "image/blocks.bmp", 
	//	D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
	//	D3DPOOL_MANAGED, D3DX_DEFAULT, 
	//	D3DX_DEFAULT, 0, NULL, NULL,
	//	&texture_blocks);
	//D3DXCreateTextureFromFileEx ( device, "image/state.bmp", 
	//	D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
	//	D3DPOOL_MANAGED, D3DX_DEFAULT, 
	//	D3DX_DEFAULT, 0, NULL, NULL,
	//	&texture_blocks);
	g_TextureList.insert ( std::pair<const char*, LPDIRECT3DTEXTURE9>( "background", TetLoadTexture ("image/background.bmp")) );
	g_TextureList.insert ( std::pair<const char*, LPDIRECT3DTEXTURE9>( "blocks", TetLoadTexture ("image/blocks.bmp")) );
	g_TextureList.insert ( std::pair<const char*, LPDIRECT3DTEXTURE9>( "state", TetLoadTexture ("image/state.bmp")) );
#endif

	return true;
}

Vertex_VT v_Start[4] = 
{
	{{0.0f, 0.0f, 0.0f},	{0.0f, 0.33f}},
	{{256.0f, 0.0f, 0.0f},	{1.0f, 0.33f}},
	{{0.0f, 128.0f, 0.0f},	{0.0f, 0.0f}},
	{{256.0f, 128.0f, 0.0f},{1.0f, 0.0f}},
};

Vertex_VT v_Win[4] = 
{
	{{0.0f, 0.0f, 0.0f},	{0.0f, 0.66f}},
	{{256.0f, 0.0f, 0.0f},	{1.0f, 0.66f}},
	{{0.0f, 128.0f, 0.0f},	{0.0f, 0.33f}},
	{{256.0f, 128.0f, 0.0f},{1.0f, 0.33f}},
};

Vertex_VT v_Lose[4] = 
{
	{{0.0f, 0.0f, 0.0f},	{0.0f, 1.0f}},
	{{256.0f, 0.0f, 0.0f},	{1.0f, 1.0f}},
	{{0.0f, 128.0f, 0.0f},	{0.0f, 0.66f}},
	{{256.0f, 128.0f, 0.0f},{1.0f, 0.66f}},
};


float sstart = 0;
TetTimer timer;

int GameState = STATE_NORMAL;

void RenderFrameDX9( ZoneInfo *Zi )
{
	LPDIRECT3DDEVICE9 device = TetGetGraphicsDeviceDX9 ();
	device->Clear( 
		0, NULL,
		D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
		D3DCOLOR_RGBA ( 20, 20, 20, 0 ), 
		1.0f,
		0
		);

	device->BeginScene ();
	device->SetTransform ( D3DTS_VIEW, ( D3DMATRIX* ) &g_view_matrix );
	device->SetTransform ( D3DTS_WORLD, ( D3DMATRIX* ) &g_world_matrix );

	device->SetFVF ( D3DFVF_XYZ | D3DFVF_TEX1 );

	//Anisotropic filtering
	//device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	//device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_ANISOTROPIC);
	//device->SetSamplerState(0, D3DSAMP_MAXANISOTROPY, 8);
	//device->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	device->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	device->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	device->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATER);
	device->SetRenderState(D3DRS_ALPHAREF, 1);



	int *fill = NULL;
	for ( int i = 0; i < 2; i++ )
	{
		if ( ( Zi + i )->PlayerID == 0 )
		{
			//player 1
			g_world_matrix.Identity();
			device->SetTransform ( D3DTS_WORLD, (D3DMATRIX* ) &g_world_matrix );
			TetRenderPlayPanel ( ( Zi + i )->zone, fill );
		}
		if ( ( Zi + i )->PlayerID == 1 )
		{
			//player 2
			g_world_matrix.Identity();
			g_world_matrix.Translate( Vector4( 490.0f, 0.0f, 0.0f, 1.0f ) );
			device->SetTransform ( D3DTS_WORLD, (D3DMATRIX*)&g_world_matrix );
			TetRenderPlayPanel ( ( Zi + i )->zone, fill );
		}
	}
	sstart += timer.Stop ();
	if ( ShowStart && sstart >= 4 )
	{
		ShowStart = false;
	}
	timer.Restart ();

	GameState = ( Zi + 0 )->State;

	if ( ShowStart )
	{
		g_world_matrix.Identity();
		g_world_matrix.Translate( Vector4( 25.0f, 300.0f, 0.0f, 1.0f ) );
		device->SetTransform ( D3DTS_WORLD, (D3DMATRIX*)&g_world_matrix );
		device->SetTexture ( 0, g_TextureList.find("state")->second );
		device->DrawPrimitiveUP ( D3DPT_TRIANGLESTRIP, 2, v_Start, sizeof (Vertex_VT) );
	}
	
	if ( GameState == STATE_WIN )
	{
		g_world_matrix.Identity();
		g_world_matrix.Translate( Vector4( 25.0f, 300.0f, 0.0f, 1.0f ) );
		device->SetTransform ( D3DTS_WORLD, (D3DMATRIX*)&g_world_matrix );
		device->SetTexture ( 0, g_TextureList.find("state")->second );
		device->DrawPrimitiveUP ( D3DPT_TRIANGLESTRIP, 2, v_Win, sizeof (Vertex_VT) );

		g_world_matrix.Identity();
		g_world_matrix.Translate( Vector4( 525.0f, 300.0f, 0.0f, 1.0f ) );
		device->SetTransform ( D3DTS_WORLD, (D3DMATRIX*)&g_world_matrix );
		device->SetTexture ( 0, g_TextureList.find("state")->second );
		device->DrawPrimitiveUP ( D3DPT_TRIANGLESTRIP, 2, v_Lose, sizeof (Vertex_VT) );
	}

	if ( GameState == STATE_LOSE )
	{
		g_world_matrix.Identity();
		g_world_matrix.Translate( Vector4( 25.0f, 300.0f, 0.0f, 1.0f ) );
		device->SetTransform ( D3DTS_WORLD, (D3DMATRIX*)&g_world_matrix );
		device->SetTexture ( 0, g_TextureList.find("state")->second );
		device->DrawPrimitiveUP ( D3DPT_TRIANGLESTRIP, 2, v_Lose, sizeof (Vertex_VT) );

		g_world_matrix.Identity();
		g_world_matrix.Translate( Vector4( 525.0f, 300.0f, 0.0f, 1.0f ) );
		device->SetTransform ( D3DTS_WORLD, (D3DMATRIX*)&g_world_matrix );
		device->SetTexture ( 0, g_TextureList.find("state")->second );
		device->DrawPrimitiveUP ( D3DPT_TRIANGLESTRIP, 2, v_Win, sizeof (Vertex_VT) );
	}

	device->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	device->EndScene();
	device->Present( NULL, NULL, NULL, NULL );
}