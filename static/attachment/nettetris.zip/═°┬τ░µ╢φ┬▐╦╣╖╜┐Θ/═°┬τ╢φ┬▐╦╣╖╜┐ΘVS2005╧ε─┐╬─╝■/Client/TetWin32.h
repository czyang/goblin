#ifndef _TETWIN32_
#define _TETWIN32_

#include "TetCommon.h"
#include "TetDX9.h"
#include "TetDef.h"

extern TetCallBack g_TetCallBack;

void TetSetWindowHandleWin32 ( HWND hWnd );
HWND TetGetWindowHandleWin32 ( void );
HINSTANCE TetGetWindowInstanceWin32(void);
static LRESULT WINAPI WndProc ( HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam );
bool TetCreateWindow ( int x, int y, int width, int height, const char *title );
bool TetProcessMessage ( void );
void TetGetWindowSize ( int &w, int &h );

#endif