#include "TetWin32.h"

static HWND g_hWnd = NULL;
static HINSTANCE g_hInstance = NULL;


static int g_iWindowPosX = 100;
static int g_iWindowPosY = 100;
static int g_iWindowWidth = 800;
static int g_iWindowHeight = 600;

void TetSetWindowHandleWin32 ( HWND hWnd )
{
	g_hWnd = hWnd;
}

void TetGetWindowSize ( int &w, int &h )
{
	w = g_iWindowWidth;
	h = g_iWindowHeight;
}

HWND TetGetWindowHandleWin32 ( void )
{
	return g_hWnd;
}

HINSTANCE TetGetWindowInstanceWin32(void)
{
	return g_hInstance;
}

static LRESULT WINAPI WndProc ( HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	switch ( message )
	{
	case WM_DESTROY:
		{
			PostQuitMessage (0);
			break;
		}
	case WM_SIZE:
		{
			int w = LOWORD (lParam);
			int h = HIWORD (lParam);
			g_iWindowWidth = w;
			g_iWindowHeight = h;
			if ( g_TetCallBack.OnSize && TetGetGraphicsDeviceType() != TET_UNKNOWN )
			{
				g_TetCallBack.OnSize (w,h);
			}
			break;
		}
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			BeginPaint ( hwnd, &ps );
			EndPaint ( hwnd, &ps );
			if ( g_TetCallBack.OnPaint )
			{
				g_TetCallBack.OnPaint ();
			}
			break;
		}
	default:
		{
			return DefWindowProc ( hwnd, message, wParam, lParam );
			break;
		}
	}
	return 0;
}

bool TetCreateWindow ( int x, int y, int width, int height, const char *title )
{
	static bool registered = false;

	WNDCLASS window_class;
	memset ( &window_class, 0, sizeof ( WNDCLASS ));
	window_class.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	window_class.lpfnWndProc = WndProc;
	window_class.hInstance = GetModuleHandle (NULL);
	window_class.hCursor = LoadCursor ( NULL, IDC_ARROW );
	window_class.hbrBackground = ( HBRUSH ) GetStockObject ( BLACK_BRUSH );
	window_class.lpszClassName = title;
	if ( !registered )
	{
		if (RegisterClass(&window_class) == 0)
			return false;
		registered = true;
	}
	DWORD window_style;

	if ( g_TetCallBack.OnSize )
	{
		window_style = WS_OVERLAPPEDWINDOW;
	}
	else
	{
		window_style = WS_BORDER | WS_SYSMENU;
	}

	RECT window_rect;
	SetRect ( &window_rect, x, y, x+width, y+height );
	AdjustWindowRect ( &window_rect, window_style, false );

	g_iWindowWidth = width;
	g_iWindowHeight = height;

	HWND window_handle = CreateWindowEx ( 
		WS_EX_APPWINDOW,
		title,
		title,
		window_style,
		window_rect.left,
		window_rect.top,
		window_rect.right - window_rect.left,
		window_rect.bottom - window_rect.top,
		NULL,
		NULL,
		window_class.hInstance,
		NULL
		);
	if ( window_handle == NULL )
		return 0;
	g_hWnd = window_handle;
	g_hInstance = window_class.hInstance;
	ShowWindow ( window_handle,SW_SHOWNORMAL );
	SetActiveWindow ( window_handle );
	return 1;
}

bool TetProcessMessage ( void )
{
	MSG msg;
	if ( PeekMessage (&msg, 0, 0, 0, PM_REMOVE ))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
		if ( msg.message == WM_QUIT )
		{
			return false;
		}
	}
	return true;
}



