#include "TetGameZone.h"
#include <map>

extern std::map<const char*, LPDIRECT3DTEXTURE9> g_TextureList;

Vertex_VT v_background[4] = 
{
	{{0.0f, 0.0f, 0.0f},{0.0f, 1.0f}},
	{{310.0f, 0.0f, 0.0f},{1.0f, 1.0f}},
	{{0.0f, 600.0f, 0.0f},{0.0f, 0.0f}},
	{{310.0f, 600.0f, 0.0f},{1.0f, 0.0f}},
};

//Render the play panel.
bool TetRenderPlayPanel ( int *GameZone, int *NextChunk )
{
	LPDIRECT3DDEVICE9 device = TetGetGraphicsDeviceDX9();

	device->SetTexture ( 0, g_TextureList.find("background")->second );
	device->DrawPrimitiveUP ( D3DPT_TRIANGLESTRIP, 2, v_background, sizeof (Vertex_VT) );

	g_world_matrix.Translate ( 5.0f, 5.0f, 0.0f );
	device->SetTransform ( D3DTS_WORLD, (D3DMATRIX*)&g_world_matrix );
	//the game area is 20*10.
	for ( int i = 0; i < 20; i++ )
	{
		for ( int j = 0; j < 10; j++ )
		{
			int block = *( GameZone + ( 10 * i + j ) );
			if ( block != 255 )			// -1 = background
			{
				RenderBlock ( block, j, i, 30 );
			}
		}
	}
	return true;
}

void RenderBlock ( int color, int x, int y, int width )
{
	float texTemp = 1.0f/BLOCKSNUM;
	float Gridx_Temp = (float)x * width, Gridy_Temp = (float)y * width;
	float color_temp = (float)color * texTemp;
	Vertex_VT v_block[4] = 
	{
		{{(float)(Gridx_Temp + 0.0),	(float)(Gridy_Temp + 0.0), 0.0f},		{(float)(color_temp + 0.0), 1.0f}},
		{{(float)(Gridx_Temp + width),	(float)(Gridy_Temp + 0.0), 0.0f},		{(float)(color_temp + texTemp), 1.0f}},
		{{(float)(Gridx_Temp + 0.0),	(float)(Gridy_Temp + width), 0.0f},		{(float)(color_temp + 0.0), 0.0f}},
		{{(float)(Gridx_Temp + width),	(float)(Gridy_Temp + width), 0.0f},		{(float)(color_temp + texTemp), 0.0f}},
	};
	LPDIRECT3DDEVICE9 device = TetGetGraphicsDeviceDX9 ();

	device->SetTexture ( 0, g_TextureList.find("blocks")->second );
	device->DrawPrimitiveUP ( D3DPT_TRIANGLESTRIP, 2, v_block, sizeof (Vertex_VT) );
}