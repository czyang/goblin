#include "TetCommon.h"

TetCallBack g_TetCallBack;
static char g_szDeviceName[8];
DevEnum g_eDeviceType = TET_UNKNOWN;

KBInfo kbi;

DevEnum TetGetGraphicsDeviceType(const char *device)
{
	if ( device )
	{
		if ( !stricmp(device, "opengl") )
		{
			return TET_OPENGL;
		}
		else if ( !stricmp(device, "dx9") )
		{
			return TET_DX9;
		}
		else if ( !stricmp(device, "dx10") )
		{
			return TET_DX10;
		}
		else
		{
			return TET_UNKNOWN;
		}
	}
	else
	{
		return g_eDeviceType;
	}
}

bool TetInitGraphicsDevice(const char *device)
{
	strcpy(g_szDeviceName, device);
	g_eDeviceType = TetGetGraphicsDeviceType(device);

	switch(g_eDeviceType)
	{
	case TET_OPENGL:
		return 0;
		break;
	case TET_DX9:
		return TetInitGraphicsDeviceDX9();
		break;
	case TET_DX10:
		return 0;
		break;
	}

	g_eDeviceType = TET_UNKNOWN;
	g_szDeviceName[0] = '\0';

	return false;
}

bool TetInitGraphicsDevice ( TetDeviceSpec &spec )
{
	strcpy( g_szDeviceName, spec.m_szDevice );
	g_eDeviceType = TetGetGraphicsDeviceType(spec.m_szDevice);

	switch(g_eDeviceType)
	{
	case TET_OPENGL:
		return false;
		break;
	case TET_DX9:
		return TetInitGraphicsDeviceDX9( &spec );
		break;
	case TET_DX10:
		return false;
		break;
	}

	g_eDeviceType = TET_UNKNOWN;
	g_szDeviceName[0] = '\0';

	return false;
}

bool TetReleaseGraphicsDevice(void)
{
	if ( !stricmp(g_szDeviceName, "opengl") )
	{
		return false;
	}
	else if ( !stricmp(g_szDeviceName, "dx9") )
	{
		return TetReleaseGraphicsDeviceDX9();
	}
	else if ( !stricmp(g_szDeviceName, "dx10") )
	{
		return false;
	}

	return false;
}

TetCallBack::TetCallBack(void)
{
	memset(this, 0, sizeof(TetCallBack));
}

void TetResizeFunc( void (*onsize)(int x, int y) )
{
	g_TetCallBack.OnSize = onsize;
}

void TetDisplayFunc( void (*onpaint)(void) )
{
	g_TetCallBack.OnPaint = onpaint;
}

void TetIdleFunc( void (*onidle)(void) )
{
	g_TetCallBack.OnIdle = onidle;
}

void TetOnCloseFunc( void (*onclose)(void) )
{
	g_TetCallBack.OnClose = onclose;
}

//Right hand coordinate system
Matrix4x4 TetMatrixLookAtRH_DirectX ( Vector4 &eye, Vector4 &lookat, Vector4 &up )
{
	Vector4 up_normalized = VectorNormalize(up);
	Vector4 zaxis = (eye - lookat); zaxis.Normalize();
	Vector4 xaxis = Vector3CrossProduct ( up_normalized, zaxis );
	Vector4 yaxis = Vector3CrossProduct ( zaxis, xaxis );

	Matrix4x4 matrix; 
	matrix.Identity();

	matrix.SetColumn(0, xaxis);
	matrix.SetColumn(1, yaxis);
	matrix.SetColumn(2, zaxis);
	matrix[3][0] = -Vector3Dot(xaxis, eye)[0];
	matrix[3][1] = -Vector3Dot(yaxis, eye)[0];
	matrix[3][2] = -Vector3Dot(zaxis, eye)[0];

	return matrix;   //view matrix
}

/*
//Left hand coordinate system
Matrix4x4 TetMatrixLookAtLH_OpenGL(Vector4 &eye, Vector4 &lookat, Vector4 &up)
{
	Vector4 up_normalized = VectorNormalize(up);
	Vector4 zaxis = (lookat - eye); zaxis.Normalize();
	Vector4 xaxis = Vector3CrossProduct(up_normalized, zaxis);
	Vector4 yaxis = Vector3CrossProduct(zaxis, xaxis);

	Matrix4x4 matrix; 
	matrix.Identity();

	matrix.SetColumn(0, xaxis);
	matrix.SetColumn(1, yaxis);
	matrix.SetColumn(2, zaxis);
	matrix[3][0] = -Vector3Dot(xaxis, eye)[0];
	matrix[3][1] = -Vector3Dot(yaxis, eye)[0];
	matrix[3][2] = -Vector3Dot(zaxis, eye)[0];

	return matrix;	//view matrix
}
*/

Matrix4x4 TetMatrixOrthoRH_DirectX(float w, float h, float z_near, float z_far)
{
	Matrix4x4 matrix;
	matrix.Identity();

	matrix[0][0] = 2.0f/w;
	matrix[1][1] = 2.0f/h;
	matrix[2][2] = 1.0f/(z_near - z_far);
	matrix[3][2] = z_near / (z_near - z_far);

	return matrix;	//orthogonal matrix
}