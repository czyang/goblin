#include "TetNetClient.h"

#define NUMLINE 999999

WSADATA              wsaData;
SOCKET               ServerSocket;
SOCKADDR_IN          ServerAddr;
int                  Port = 3003;

void GetIpAdd ( char *ip )
{
	FILE *fp;
	//char ip[16];
	char port[6];

#ifdef _DEBUG
	fp = fopen ( "../../Config.txt", "r" );
#else
	fp = fopen ( "Config.txt", "r" );
#endif

	if ( fp == NULL )
	{
		exit(1);
	}
	fgets ( ip, NUMLINE, fp );

	fclose (fp);
}

bool InitNetClient ( void )
{
	int Port = NETPORT;
	char IpAddress[16];

	WSAStartup(MAKEWORD(2,2), &wsaData);

	GetIpAdd (IpAddress);
	//Create a socket with TCP protocol.
	ServerSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	ServerAddr.sin_family = AF_INET;
	ServerAddr.sin_port = htons(Port);
	ServerAddr.sin_addr.s_addr = inet_addr(IpAddress);

	//Try connect to the Server. 
	connect(ServerSocket, (SOCKADDR *) &ServerAddr, sizeof(ServerAddr));

	return TRUE;

}

void TetGetServerMessage ( ZoneInfo *Zi )
{
	fd_set  fdread;
	FD_ZERO( &fdread );
	FD_SET ( ServerSocket, &fdread );
	timeval tm = {20, 0};
	int ret = 0;
	
	ret = select ( 0, &fdread, NULL, NULL, &tm );

	switch (ret)
	{
	case 0:	// No data got.
		break;
	case 1:// Get data.
		int iResult;
		iResult = recv ( ServerSocket, ( char* ) Zi, sizeof ( ZoneInfo ), 0 );
		if ( iResult <= 0 )
		{
			exit(1);
		}
		iResult = recv ( ServerSocket, ( char* ) ( Zi + 1 ), sizeof ( ZoneInfo ), 0 );
		if ( iResult <= 0 )
		{
			exit(1);
		}
		break;
	case SOCKET_ERROR:
		exit (1);
		break;
	}
}

void TetSend ( const char *buf, int len )
{
	int iResult;
	iResult = send ( ServerSocket, buf, len, 0 );
	if ( iResult == SOCKET_ERROR )
	{
		exit(0);
	}
}

void TetRecv ( char *buf, int len )
{
	int iResult;
	iResult = recv ( ServerSocket, buf, len, 0 );
	if ( iResult == SOCKET_ERROR )
	{
		exit(0);
	}
}

void ReleaseNetClient ( void )
{
	closesocket(ServerSocket);
	WSACleanup();
}