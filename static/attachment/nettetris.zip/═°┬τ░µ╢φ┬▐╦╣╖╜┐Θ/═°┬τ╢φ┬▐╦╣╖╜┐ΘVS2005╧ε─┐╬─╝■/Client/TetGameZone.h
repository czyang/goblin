#ifndef _TETGAMEZONE_
#define _TETGAMEZONE_

#include "TetDX9.h"

#define BLOCKSNUM 8
#define WIDTHBLOCK 32

bool TetRenderPlayPanel ( int *GameZone, int *NextChunk );
void RenderBlock ( int color, int PosX, int PosY, int PosZ );

#endif